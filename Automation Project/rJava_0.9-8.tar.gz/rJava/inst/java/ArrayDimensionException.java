public class ArrayDimensionException extends Exception{
	public ArrayDimensionException(String message){
		super( message ) ; 
	}
}
